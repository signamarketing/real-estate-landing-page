<?php

namespace eightb\home_value;

use \Exception;

/**
	@brief		Handle all shortcodes.
	@since		2016-12-09 21:33:57
**/
trait shortcodes_trait
{
	/**
		@brief		Show the base form and the necessary javascript.
		@since		2016-12-11 13:21:19
	**/
	public function shortcode_8b_home_value()
	{
		if ( ! session_id() )
			return 'Unable to start the PHP session on this server.';

		$replacements = [
			'content' => '',		// Content should be the first text replaced.
			'google_api_key' => 'AIzaSyADO3hJlNyLiEk-19vo3Zu9vKF_895euwg',		// $this->get_site_option( 'google_api_key' )
			'js' => $this->paths( 'url' ) . '/js/js.js',
		];
		$template = '';

		$tempform = $this->form();
		$tempform->prefix( '8b_home_value' );

		// Now decide which content template to load.
		if (
			empty( $_POST )
			OR ( ! isset( $_POST[ '8b_home_value' ] ) )
			OR ( ! isset( $_POST[ '8b_home_value' ][ 'nonce' ] ) )
		)
		{
			unset( $_SESSION[ '8b_hv_found_address' ] );
			// Deugging the address? Try this one: 1600 Tremont Street;02120
			$template = $this->get_text_file( 'address_search_form' );
			$replacements[ 'address_search_form_address_input_placeholder' ] = $this->get_local_or_site_option( 'address_search_form_address_input_placeholder' );
			$replacements[ 'address_search_form_submit_button_text' ] = $this->get_local_or_site_option( 'address_search_form_submit_button_text' );
		}
		else
		{
			$post = $_POST[ '8b_home_value' ];

			// Check the nonce.
			$nonce_value = $post[ 'nonce' ];
			if ( ! wp_verify_nonce( $nonce_value, $this->get_nonce_key() ) )
				wp_die( 'Security check failed.' );

			$form = $this->form();
			$form->prefix( '8b_home_value' );

			// First name's first.
			if ( $this->get_local_or_site_option( 'lead_form_first_name_visible' ) == 'on' )
			{
				$ph = $this->get_local_or_site_option( 'lead_form_first_name_placeholder' );
				$form->text( 'lead_first_name' )
					->label( $ph )
					->placeholder( $ph )
					->required( $this->get_local_or_site_option( 'lead_form_first_name_required' )  == 'on' );
			}

			// Then last name.
			if ( $this->get_local_or_site_option( 'lead_form_last_name_visible' ) == 'on' )
			{
				$ph = $this->get_local_or_site_option( 'lead_form_last_name_placeholder' );
				$form->text( 'lead_last_name' )
					->label( $ph )
					->placeholder( $ph )
					->required( $this->get_local_or_site_option( 'lead_form_last_name_required' )  == 'on' );
			}

			// Then phone.
			if ( $this->get_local_or_site_option( 'lead_form_phone_visible' ) == 'on' )
			{
				$ph = $this->get_local_or_site_option( 'lead_form_phone_placeholder' );
				$form->text( 'lead_phone' )
					->label( $ph )
					->placeholder( $ph )
					->required( $this->get_local_or_site_option( 'lead_form_phone_required' )  == 'on' );
			}

			// E-mail is always required.
			$ph = $this->get_local_or_site_option( 'lead_form_email_placeholder' );
			$form->text( 'lead_email' )
				->label( $ph )
				->placeholder( $ph )
				->required();

			// And now the submit button.
			$form->primary_button( 'submit' )
				->value( $this->get_local_or_site_option( 'lead_form_submit_button_text' ) );

			if ( ! isset( $post[ 'lead_email' ] ) )
			{
				// Did we find the address?
				$address_found = false;

				// Look up the address in the API.
				$address = sanitize_text_field( $post[ 'found_address' ] );
				$_SESSION[ '8b_searched_address' ] = sanitize_text_field( $post[ 'address' ] );
				$address = explode( ';', $address );
				try
				{
					// No proper address found.
					if ( count( $address ) < 2 )
						$address []= '';

					$json = $this->get_api()->search( $address[ 0 ], $address[ 1 ] );

					$decoded = json_decode( $json->result );

					if ( ! is_object( $decoded ) )
						throw new Exception( 'Invalid JSON data.' );

					if ( $decoded->success != true )
						throw new Exception( 'Not success.' );

					// Save our new stats.
					$this->update_site_option( 'refill_date', $json->refill_date );
					$this->update_site_option( 'results_left', $json->results_left );

					$result = $decoded->result;
					$_SESSION[ '8b_hv_found_address' ] = $result;
					$address_found = true;
				}
				catch( Exception $e )
				{
				}

				if ( $address_found )
				{
					$g_key = 'AIzaSyADO3hJlNyLiEk-19vo3Zu9vKF_895euwg'; // $this->get_local_option( 'google_api_key' );
					if ( $g_key == '' )
					{
						if ( ! $this->get_site_option( 'force_own_google_api_key' ) )
							$g_key = $this->get_site_option( 'google_api_key' );
					}
					$replacements[ 'address_street_view' ] = sprintf( 'https://maps.googleapis.com/maps/api/streetview?location=%s,%s&size=RESOLUTION&key=%s',
						$result->address->deliveryLine,
						$result->address->zip,
						$g_key
					);
					$data = $_SESSION[ '8b_hv_found_address' ];
					$replacements[ 'data_address' ] = sprintf( '%s, %s', $data->address->deliveryLine, $data->address->city );
					$replacements[ 'lead_form_address_found_text' ] = $this->get_local_or_site_option( 'lead_form_address_found_text' );

					$template = $this->get_text_file( 'lead_info_form_with_address' );
				}
				else
				{
					$_SESSION[ '8b_hv_found_address' ] = false;
					$replacements[ 'lead_form_address_not_found_text' ] = $this->get_local_or_site_option( 'lead_form_address_not_found_text' );
					$template = $this->get_text_file( 'lead_info_form_without_address' );
				}

				$replacements[ 'lead_form' ] = $form . '';
			}
			else
			{
				$lead = new classes\Lead();

				// Save everything in the post that starts with "lead".
				foreach( $post as $key => $value )
				{
					if ( strpos( $key, 'lead_' ) === false )
						continue;
					$value = sanitize_text_field( $value );
					$value = stripslashes( $value );
					$lead->meta->$key = $value;
				}

				if ( $_SESSION[ '8b_hv_found_address' ] )
				{
					// Found the address
					$post_content = $this->get_text_file( 'lead_content_address' );

					$data = $_SESSION[ '8b_hv_found_address' ];
					$replacements = array_merge( $replacements, $this->data_to_replacements( $data ) );
				}
				else
				{
					// Did not find the address.
					$post_content = $this->get_text_file( 'lead_content_no_address' );
					// false = return n/a in everything.
					$replacements = array_merge( $replacements, $this->data_to_replacements( false ) );
				}

				$replacements = array_merge( $replacements, $lead->get_shortcodes() );
				$replacements[ 'searched_address' ] = $_SESSION[ '8b_searched_address' ];

				$post_content = $this->replace_shortcodes( $post_content, $replacements );
				$lead->set( 'post_content', $post_content );

				$lead->save();

				$this->send_lead_to_webhooks( $lead );

				// We can only set this after the lead exists.
				if ( $_SESSION[ '8b_hv_found_address' ] )
					$lead->address_found();
				else
					$lead->address_found( false );

				$this->debug( 'Maybe broadcasting lead.' );
				$lead->broadcast();
				$this->debug( 'Sending lead e-mail.' );
				$this->send_lead( $lead, $replacements );

				if ( ! $_SESSION[ '8b_hv_found_address' ] )
				{
					$this->debug( 'Did not find address. Contact you later.' );
					// Did not find the address.
					$replacements[ 'no_address_page_text' ] = $this->get_local_or_site_option( 'no_address_page_text' );
					$template = $this->get_text_file( 'no_address_page' );
				}
				else
				{
					$this->debug( 'Address found. Show the value.' );
					// Found the address.
					$template = $this->get_text_file( 'show_value_page' );
					$data = $_SESSION[ '8b_hv_found_address' ];
					$data_replacements = $this->data_to_replacements( $data );
					$replacements = array_merge( $replacements, $data_replacements );
				}

				unset( $_SESSION[ '8b_hv_found_address' ] );
			}
		}

		// Get the current URL.
		$replacements[ 'url' ] = remove_query_arg( 'asmksb' );

		$template = $this->replace_shortcodes( $template, $replacements );

		return $template;
	}

	/**
		@brief		Convert this Home Value data to a replacements array.
		@since		2017-02-24 23:15:37
	**/
	public function data_to_replacements( $data )
	{
		$replacements = [];

		if ( ! $data )
		{
			foreach( [ 'data_address_city',
				'data_address_state',
				'data_address_street',
				'data_address_zipcode',
				'data_baths',
				'data_beds',
				'data_lotSizeSqFt',
				'data_size',
				'data_address',
				'data_valuation_low',
				'data_valuation_medium',
				'data_valuation_high' ] as $key )
				$replacements[ $key ] = 'n/a';
		}
		else
		{
			$replacements[ 'data_address_city' ] = $data->address->city;
			$replacements[ 'data_address_state' ] = $data->address->state;
			$replacements[ 'data_address_street' ] = $data->address->deliveryLine;
			$replacements[ 'data_address_zipcode' ] = $data->address->zip;

			if ( isset( $data->attributes->baths ) )
				$value = $data->attributes->baths;
			else
				$value = 'n/a';
			$replacements[ 'data_baths' ] = $value;

			if ( isset( $data->attributes->beds ) )
				$value = $data->attributes->beds;
			else
				$value = 'n/a';
			$replacements[ 'data_beds' ] = $value;

			$value = $data->attributes->lotSize->sqft;
			$replacements[ 'data_lotSizeSqFt' ] = $this->number_format( $value );
			$value = $data->attributes->size;
			$replacements[ 'data_size' ] = $this->number_format( $value );

			$replacements[ 'data_address' ] = sprintf( '%s, %s', $data->address->street, $data->address->city );

			$value = $data->valuations->general->low;
			$value = $value * .98;
			$value = $this->number_format( $value );
			$replacements[ 'data_valuation_low' ] = $value;

			$value = $data->valuations->general->EMV;
			$value = $value * 1.06;
			$value = $this->number_format( $value );
			$replacements[ 'data_valuation_medium' ] = $value;

			$value = $data->valuations->general->high;
			$value = $value * 1.20;
			$value = $this->number_format( $value );
			$replacements[ 'data_valuation_high' ] = $value;
		}

		return $replacements;
	}
}
