<?php

namespace plainview\sdk_eightb_home_value\wordpress\object_stores;

/**
	@brief		Master class for Wordpress stores.
	@since		2016-01-02 01:19:06
**/
trait Store
{
	use \plainview\sdk_eightb_home_value\object_stores\Store;
}
