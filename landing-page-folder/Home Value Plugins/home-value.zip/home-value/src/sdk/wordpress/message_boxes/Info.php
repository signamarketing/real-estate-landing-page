<?php

namespace plainview\sdk_eightb_home_value\wordpress\message_boxes;

/**
	@brief		An info or updated type of message box.
	@since		2015-12-21 20:30:20
**/
class Info
	extends Box
{
	// Nothing to override here since info is "updated", which is the default.
}
