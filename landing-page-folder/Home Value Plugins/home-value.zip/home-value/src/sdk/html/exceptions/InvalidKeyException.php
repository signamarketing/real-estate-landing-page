<?php

namespace plainview\sdk_eightb_home_value\html\exceptions;

class InvalidKeyException extends \Exception
{
}
