<?php

namespace plainview\sdk_eightb_home_value\table;

/**
	@brief		Cell of type TH.
	@since		20130430
**/
class th
	extends cell
{
	public $tag = 'th';
}
