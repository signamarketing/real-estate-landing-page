<?php

require_once( __DIR__ . '/../base.php' );
require_once( __DIR__ . '/../html/attribute.php' );
require_once( __DIR__ . '/../html/element.php' );
require_once( __DIR__ . '/../html/indentation.php' );
require_once( __DIR__ . '/form.php' );
