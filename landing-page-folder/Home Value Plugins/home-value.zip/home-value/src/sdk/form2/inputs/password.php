<?php

namespace plainview\sdk_eightb_home_value\form2\inputs;

/**
	@brief		Password text input.
	@author		Edward Plainview <edward@plainview.se>
	@copyright	GPL v3
	@version	20130524
**/
class password
	extends text
{
	public $type = 'password';
}

