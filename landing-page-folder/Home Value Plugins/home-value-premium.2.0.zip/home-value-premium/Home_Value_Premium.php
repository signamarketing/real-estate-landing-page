<?php
/*
Author:			8blocks
Author Email:	support@8blocks.com
Author URI:		https://homevalueplugin.com
Description:	Adds premium features to the <a href="https://wordpress.org/plugins/home-value/">8b Home Value plugin</a>.
Plugin Name:	8b Home Value Premium
Plugin URI:		https://wordpress.org/plugins/home-value/
Version:		2.0
*/

DEFINE( 'EIGHTB_HOME_VALUE_PREMIUM_PLUGIN_VERSION', 2.0 );

/**
	@brief		Loader for the HV Premium plugin.
	@details	It's loaded this way because it uses the same SDK the Home Value uses.
	@since		2017-02-01 14:58:49
**/
class Home_Value_Premium_Loader
{
	/**
		@brief		The premium plugin object, once loaded.
		@since		2017-02-01 14:59:21
	**/
	public $plugin = false;

	/**
		@brief		Constructor.
		@since		2015-10-29 15:17:29
	**/
	public function __construct()
	{
		// Optimally, we would hook into an "we are loaded" action that HV provides, but this will also do.
		add_action( 'plugins_loaded', [ $this, 'plugin' ] );
		register_activation_hook( __FILE__, [ $this, 'activate' ] );
		register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );
	}

	public function activate()
	{
		if ( ! function_exists( 'EightB_Home_Value' ) )
			return;
		$this->plugin()->activate();
	}

	public function deactivate()
	{
		if ( ! function_exists( 'EightB_Home_Value' ) )
			return;
		$this->plugin()->deactivate();
	}

	/**
		@brief		Init the pack, or return the pack class if already initialized.
		@since		2015-10-29 15:20:00
	**/
	public function plugin()
	{
		if ( ! function_exists( 'EightB_Home_Value' ) )
			return;
		if ( $this->plugin === false )
		{
			require_once( __DIR__ . '/vendor/autoload.php' );
			$this->plugin = new \eightb\home_value_premium\Home_Value_Premium();
		}
		return $this->plugin;
	}
}

/**
	@brief		Return the instance of the Home Value Premium plugin.
	@since		2017-02-01 14:55:53
**/
function EightB_Home_Value_Premium()
{
	return eightb\home_value_premium\Home_Value_Premium::instance();
}

new Home_Value_Premium_Loader();
