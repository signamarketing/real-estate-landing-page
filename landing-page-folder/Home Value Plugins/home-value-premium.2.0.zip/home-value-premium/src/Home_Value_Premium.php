<?php

namespace eightb\home_value_premium;

/**
	@brief		The actual Premium class.
	@since		2017-02-01 15:01:58
**/
class Home_Value_Premium
	extends \eightb\home_value\classes\Premium
{
	use admin_menu_trait;

	/**
		@brief		Constructor.
		@since		2017-02-01 15:06:01
	**/
	public function _construct()
	{
		$this->init_admin_menu_trait();
		$this->edd_init();
	}

	/**
		@brief		Activate!
		@since		2017-02-09 22:28:10
	**/
	public function activate()
	{
		// Try to activate ourself with the HV API key.
		if ( ! function_exists( 'EightB_Home_Value' ) )
			return;

		$hv = EightB_Home_Value();

		$api_key = EightB_Home_Value()->get_home_value_api_key();

		if ( $api_key == '' )
			return;

		// Set the key as our license key.
		$this->update_site_option( 'edd_updater_license_key', $api_key );
		$this->edd_activate_license();
	}

	/**
		@brief		Return the version of the premium plugin, for the updater.
		@since		2017-02-16 20:25:51
	**/
	public function edd_get_plugin_version()
	{
		return EIGHTB_HOME_VALUE_PREMIUM_PLUGIN_VERSION;
	}
}
