<?php

namespace eightb\home_value_premium;

/**
	@brief		All admin menu functions.
	@since		2016-12-09 20:29:44
**/
trait admin_menu_trait
{
	/**
		@brief		Add ourselves to the settings.
		@since		2017-02-01 21:35:30
	**/
	public function admin_menu_premium_settings()
	{
		$this->edd_admin_license_tab();
	}

	/**
		@brief		eightb_home_value_prepare_menu
		@since		2017-02-01 17:18:00
	**/
	public function eightb_home_value_prepare_settings_tabs( $action )
	{
		$action->tabs->tab( 'premium' )
			->callback_this( 'admin_menu_premium_settings' )
			->heading_( 'Premium plugin settings' )
			->name_( 'Premium' );
	}

	/**
		@brief		init_admin_menu_trait
		@since		2017-02-01 17:17:25
	**/
	public function init_admin_menu_trait()
	{
		$this->add_action( 'eightb_home_value_prepare_settings_tabs' );
	}
}
